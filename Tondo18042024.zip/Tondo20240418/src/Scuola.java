import java.util.*;

public class Scuola {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in); // creazione dello scanner
		ArrayList<Studente> studenti = new ArrayList<Studente>(); // Istanziazione dell'ArrayList di classe Studente
																	// necessario a contenere la lista degli utenti
		Studente s = new Studente(); // istanza dell'oggetto Studente per usufruire degli attributi e dei metodi
										// della classe Studente
		int scelta = 0;
		do { // ciclo do while per il menu
			System.out.println(" Men� principale:\r\n" + "1. Aggiungi studente\r\n" + "2. Visualizza studenti\r\n"
					+ "3. Rimuovi studente \r\n" + "4. Modifica studente\r\n" + "5. Esci");
			scelta = keyboard.nextInt(); // input dell'utente della scelta del menu
			switch (scelta) { // costrutto switch per il menu
			case 1:
				aggiungiStudente(keyboard, studenti); // invocazione del metodo
				break;
			case 2:
				visualizzaStudenti(studenti, s);
				break;
			case 3:
				rimuoviStudente(keyboard, studenti, s);
				break;
			case 4:
				modificaStudente(keyboard, studenti, s);
				break;
			case 5:
				System.out.println(" Uscita in corso... ");
			}

		} while (scelta != 5);
		System.out.println(" Uscita completata correttamente ");
	}

	public static void aggiungiStudente(Scanner keyboard, ArrayList<Studente> studenti) {
		System.out.println(" Inserisci il nome ");
		String nome = keyboard.next();
		System.out.println(" Inserisci l'et� ");
		int eta = keyboard.nextInt();
		System.out.println(" Insersci la classe ");
		String classe = keyboard.next();
		studenti.add(new Studente(nome, eta, classe));
	}

	public static void visualizzaStudenti(ArrayList<Studente> studenti, Studente s) {
		if (studenti.size() > 0) { // condizione utile a evitare il bug in caso di lista vuota
			for (Studente i : studenti) {
				System.out.println((studenti.lastIndexOf(i) + 1) + ". Studente : " + i.getNome() + " et�: " + i.getEta()
						+ " classe: " + i.getClasse());
			}
		} else {
			System.out.println(" Impossibile stampare, la lista � vuota ");
		}

	}

	public static void rimuoviStudente(Scanner keyboard, ArrayList<Studente> studenti, Studente s) {
		for (Studente i : studenti) {
			System.out.println((studenti.lastIndexOf(i) + 1) + ". " + i.getNome());
		}
		System.out.println(" Quale studente vuoi rimuovere? (Inserisci il numero) ");
		int r = keyboard.nextInt();
		if (r > 0 && r <= studenti.size()) {
			studenti.remove(r - 1);
			System.out.println(" Studente rimosso con successo!");
		} else {
			System.out.println(" Impossibile rimuovere, l'indice inserito non esiste ");
		}
	}

	public static void modificaStudente(Scanner keyboard, ArrayList<Studente> studenti, Studente s) {
		if (studenti.size() > 0) {
			visualizzaStudenti(studenti, s);

			System.out.println(" Quale utente vuoi modificare? (Inserisci indice) ");
			int m = keyboard.nextInt();
			if (m > 0 && m <= studenti.size()) { // condizione per evitare il bug in caso di indice errato
				System.out.println(" Cosa desideri modificare? 1-Nome, 2-Et�, 3- Classe ");
				int scelta = keyboard.nextInt();
				switch (scelta) {
				case 1:
					System.out.println(" Inserisci il nuovo nome ");
					String nome = keyboard.next();
					studenti.get(m - 1).setNome(nome);
					break;
				case 2:
					System.out.println(" Inserisci la nuova et� ");
					int eta = keyboard.nextInt();
					studenti.get(m - 1).setEta(eta);
					break;
				case 3:
					System.out.println(" Inserisci la nuova classe ");
					String classe = keyboard.next();
					studenti.get(m - 1).setClasse(classe);
				}
				System.out.println(" Modifica effettuata con successo! Nome: " + studenti.get(m - 1).getNome()
						+ " Et�: " + studenti.get(m - 1).getEta() + " Classe: " + studenti.get(m - 1).getClasse());
			} else {
				System.out.println(" L'indice inserito non � valido, inserire un indice valido ");
			}
		} else {
			System.out.println(" Impossibile modificare, la lista � vuota ");
		}
	}

}
