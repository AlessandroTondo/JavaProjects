
public class Studente {
	String nome; // Attributi
	int eta;
	String classe;

	Studente() { // Costruttore vuoto necessario a creare l'oggetto nella classe scuola
	}

	Studente(String nome, int eta, String classe) { // costruttore necessario all'ArrayList degli studenti
		this.nome = nome;
		this.eta = eta;
		this.classe = classe;
	}

	public String getClasse() { // get necessario a stampare la classe
		return classe;
	}

	public int getEta() { // get necessario a stampare la et�
		return eta;
	}

	public String getNome() { // get necessario a stampare il nome
		return nome;
	}

	public void setClasse(String classe) { // set necessario a modificare la classe
		this.classe = classe;
	}

	public void setEta(int eta) { // set necessario a modificare l'et�
		this.eta = eta;
	}

	public void setNome(String nome) { // set necessario a modificare il nome
		this.nome = nome;
	}

	public String toStringnome() {
		String attributo = this.nome.toString();
		return attributo;
	}

	public String toStringclasse() {
		String attributo = this.classe.toString();
		return attributo;
	}
}
